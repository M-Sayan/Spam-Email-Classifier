# Spam Email Classifier

A Naive Bayes + TF-IDF spam classifier built with scikit-learn.

---

## Project Structure

```
spam-classifier/
├── spam_classifier.py     ← Main ML script
├── requirements.txt       ← Python dependencies
├── SMSSpamCollection      ← Dataset (download separately)
└── spam_model.pkl         ← Saved model (generated after training)
```

---

## Setup Instructions

### Step 1 — Install Python dependencies

```bash
pip install -r requirements.txt
```

### Step 2 — Download the dataset

1. Go to: https://archive.ics.uci.edu/ml/datasets/sms+spam+collection
2. Download the zip file and extract it
3. Place the file named **SMSSpamCollection** in the same folder as `spam_classifier.py`

### Step 3 — Run the classifier

```bash
python spam_classifier.py
```

---

## Expected Output

```
Dataset loaded!
ham     4825
spam     747

Training samples : 4459
Testing  samples : 1115

Training complete!

Accuracy : 0.9821

Classification Report:
              precision    recall  f1-score
Ham               0.99      0.99      0.99
Spam              0.97      0.95      0.96

── Sample Predictions ──
  Input : Congratulations! You've won a FREE iPhone...
  Result: SPAM  (98.3% spam confidence)

  Input : Are we still on for the 3pm meeting tomorrow?...
  Result: HAM   (1.2% spam confidence)
```

---

## How It Works

| Step | What happens |
|------|--------------|
| 1 | Load the SMS Spam Collection dataset |
| 2 | Clean text: lowercase, remove punctuation |
| 3 | TF-IDF vectorization (unigrams + bigrams) |
| 4 | Train Multinomial Naive Bayes classifier |
| 5 | Evaluate with accuracy, precision, recall, F1 |
| 6 | Save model to `spam_model.pkl` |
| 7 | Predict new emails with confidence scores |

---

## Load Saved Model Later

```python
import pickle

with open("spam_model.pkl", "rb") as f:
    model = pickle.load(f)

result = model.predict(["your email text here"])
print("spam" if result[0] == 1 else "ham")
```
