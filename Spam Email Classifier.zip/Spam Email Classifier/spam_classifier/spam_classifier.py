import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import pickle
import re

# ── 1. Load Dataset ───────────────────────────────────────────────────────────
# Download the SMS Spam Collection dataset from:
# https://archive.ics.uci.edu/ml/datasets/sms+spam+collection
# Place the file "SMSSpamCollection" in the same folder as this script.

df = pd.read_csv(
    "SMSSpamCollection",
    sep="\t",
    names=["label", "text"]
)

print("Dataset loaded!")
print(df["label"].value_counts())
print(f"Total samples: {len(df)}\n")

# ── 2. Preprocess Text ────────────────────────────────────────────────────────

def clean_text(text):
    text = text.lower()
    text = re.sub(r"[^a-z0-9\s]", "", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text

df["text"] = df["text"].apply(clean_text)
df["label"] = df["label"].map({"ham": 0, "spam": 1})

print("Sample cleaned texts:")
print(df[["text", "label"]].head(3).to_string())
print()

# ── 3. Split Data ─────────────────────────────────────────────────────────────

X_train, X_test, y_train, y_test = train_test_split(
    df["text"],
    df["label"],
    test_size=0.2,
    random_state=42,
    stratify=df["label"]
)

print(f"Training samples : {len(X_train)}")
print(f"Testing  samples : {len(X_test)}\n")

# ── 4. Build Pipeline ─────────────────────────────────────────────────────────

model = Pipeline([
    ("tfidf", TfidfVectorizer(
        stop_words="english",
        ngram_range=(1, 2),    # unigrams + bigrams
        max_features=10_000
    )),
    ("clf", MultinomialNB(alpha=0.1))
])

# ── 5. Train ──────────────────────────────────────────────────────────────────

print("Training model...")
model.fit(X_train, y_train)
print("Training complete!\n")

# ── 6. Evaluate ───────────────────────────────────────────────────────────────

y_pred = model.predict(X_test)

print(f"Accuracy : {accuracy_score(y_test, y_pred):.4f}\n")
print("Classification Report:")
print(classification_report(y_test, y_pred, target_names=["Ham", "Spam"]))
print("Confusion Matrix:")
print(confusion_matrix(y_test, y_pred))
print()

# ── 7. Save Model ─────────────────────────────────────────────────────────────

with open("spam_model.pkl", "wb") as f:
    pickle.dump(model, f)
print("Model saved to spam_model.pkl\n")

# ── 8. Predict New Emails ─────────────────────────────────────────────────────

def predict(text):
    cleaned = clean_text(text)
    prob = model.predict_proba([cleaned])[0]
    label = "SPAM" if prob[1] > 0.5 else "HAM"
    print(f"  Input : {text[:60]}...")
    print(f"  Result: {label}  ({prob[1]*100:.1f}% spam confidence)\n")
    return label, prob

print("── Sample Predictions ──")
predict("Congratulations! You've won a FREE iPhone. Click here to claim your prize NOW!!!")
predict("Are we still on for the 3pm meeting tomorrow? Let me know.")
predict("URGENT: Your bank account has been suspended. Verify your details immediately.")
predict("Here is the report you asked for. Let me know if you need any changes.")
